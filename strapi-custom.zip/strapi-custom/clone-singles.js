const fs = require("fs");
const path = require("path");

const apiBase = path.join(__dirname, "src", "api");
const templateName = "chackai";
const newNames = ["vadakara", "poovar", "thalassery", "trivandrum"];

const templatePath = path.join(apiBase, templateName);

newNames.forEach((name) => {
  const newApiPath = path.join(apiBase, name);
  if (fs.existsSync(newApiPath)) {
    console.log(`⚠️  ${name} already exists. Skipping...`);
    return;
  }

  fs.mkdirSync(newApiPath, { recursive: true });

  // Copy and rename controller, route, service files
  ["controllers", "routes", "services"].forEach((folder) => {
    const srcFolder = path.join(templatePath, folder);
    const destFolder = path.join(newApiPath, folder);
    fs.mkdirSync(destFolder, { recursive: true });

    const srcFile = path.join(srcFolder, `${templateName}.js`);
    const destFile = path.join(destFolder, `${name}.js`);
    if (fs.existsSync(srcFile)) {
      fs.copyFileSync(srcFile, destFile);
    }
  });

  // Content-type folder setup
  const contentTypeFolder = path.join(newApiPath, "content-types", name);
  fs.mkdirSync(contentTypeFolder, { recursive: true });

  const schemaTemplatePath = path.join(
    templatePath,
    "content-types",
    templateName,
    "schema.json"
  );

  if (!fs.existsSync(schemaTemplatePath)) {
    console.error(`❌ Missing schema template at ${schemaTemplatePath}`);
    return;
  }

  const schema = JSON.parse(fs.readFileSync(schemaTemplatePath, "utf8"));

  // Properly update singular, plural and collectionName
  const pluralName = `${name}s`;
  const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);

  schema.collectionName = pluralName;
  schema.info.singularName = name;
  schema.info.pluralName = pluralName;
  schema.info.displayName = capitalizedName;

  const newSchemaPath = path.join(contentTypeFolder, "schema.json");
  fs.writeFileSync(newSchemaPath, JSON.stringify(schema, null, 2), "utf8");

  // Optional: copy other custom files like mm.js if needed
  const mmPath = path.join(
    templatePath,
    "content-types",
    templateName,
    "mm.js"
  );
  if (fs.existsSync(mmPath)) {
    fs.copyFileSync(mmPath, path.join(contentTypeFolder, "mm.js"));
  }

  console.log(`✅ Created API for: ${name}`);
});
