// Example for a single type called "homepage"
const fetchSingleType = async () => {
  console.log("data");

  const token =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNzQ3ODk3NzM1LCJleHAiOjE3NDg1MDI1MzV9.GLDYXOq6ecDJbrq59pffnzo6z0qbza5sEmgH5XM-RVQ";
  const token1 =
    "500fd67d8f473aecf5dd09f59ec4dbdf91debdd4efa4c3a19ead60ee10a3668ea712625f36daa16d03516eab3ee6f8c571c2bc466b569f4d62e0ea0e85927ef8af1d84ec1e9a8aab036035b4d1d818d5d7779e9e90201162859dfbbf583895b95c1fb4c8ac6bf2e9b6e6a3442d30c61a8327e3bb3261edb62e21e3ab74352e77";
  const response = await fetch("http://localhost:1337/api/chackai", {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token1}`,
      "Content-Type": "application/json",
    },
  });

  const data = await response.json();
  console.log(data);

  return data;
};
fetchSingleType();
