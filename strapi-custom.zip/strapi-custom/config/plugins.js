// module.exports = () => ({});
// module.exports = ({ env }) => ({
//   "strapi-v5-plugin-populate-deep": {
//     config: {
//       defaultDepth: 3, // Default is 5
//     },
//   },
// });
module.exports = {
  "users-permissions": {
    config: {
      jwt: {
        expiresIn: "7d", // Token expiration time
      },
    },
  },
};