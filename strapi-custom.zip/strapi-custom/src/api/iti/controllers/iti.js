'use strict';

/**
 * iti controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::iti.iti');
