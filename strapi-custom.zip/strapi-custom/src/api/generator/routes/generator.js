module.exports = {
  routes: [
    {
      method: "POST",
      path: "/generate",
      handler: "generator.createAPIs",
      config: {
        auth: false,
      },
    },
    {
      method: "POST",
      path: "/delete",
      handler: "generator.deleteAPI",
      config: { auth: false },
    },
  ],
};
