"use strict";
const {
  generateFromTemplate,
  deleteAPI,
} = require("../../../utils/apigenerator");

module.exports = {
  async createAPIs(ctx) {
    const { names } = ctx.request.body;
    if (!Array.isArray(names)) {
      return ctx.badRequest("Invalid 'names'");
    }

    try {
      generateFromTemplate("chackai", names);
      ctx.send({ message: "APIs created. Please restart Strapi." });
    } catch (err) {
      console.error(err);
      ctx.internalServerError("Failed to generate APIs");
    }
  },
  async deleteAPI(ctx) {
    const { name } = ctx.request.body;
    if (!name) {
      return ctx.badRequest("Missing 'name' to delete");
    }

    try {
      const deleted = deleteAPI(name);
      if (!deleted) {
        return ctx.notFound("API not found");
      }
      ctx.send({ message: `🗑️ API '${name}' deleted. Please restart Strapi.` });
    } catch (err) {
      console.error(err);
      ctx.internalServerError("Failed to delete API");
    }
  },
};
