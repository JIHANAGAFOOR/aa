'use strict';

/**
 * varkkala router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::varkkala.varkkala');
