'use strict';

/**
 * varkkala service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::varkkala.varkkala');
