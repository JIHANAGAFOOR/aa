'use strict';

/**
 * varkkala controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::varkkala.varkkala');
