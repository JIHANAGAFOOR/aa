'use strict';

/**
 * vamanapuram service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::vamanapuram.vamanapuram');
