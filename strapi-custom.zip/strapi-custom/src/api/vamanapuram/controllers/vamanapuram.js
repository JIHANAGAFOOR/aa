'use strict';

/**
 * vamanapuram controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::vamanapuram.vamanapuram');
