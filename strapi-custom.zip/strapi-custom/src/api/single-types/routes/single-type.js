module.exports = {
  routes: [
    {
      method: "GET",
      path: "/list-singles",
      handler: "single-types.list",
      config: {
        auth: false,
      },
    },
  ],
};
