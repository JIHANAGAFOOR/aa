"use strict";

module.exports = {
  async list(ctx) {
    const allContentTypes = strapi.contentTypes;
    const singles = [];

    for (const uid in allContentTypes) {
      // Skip plugins and only focus on user-defined APIs
      if (!uid.startsWith("api::")) continue;

      const ct = allContentTypes[uid];
      const kind = ct.kind || ct.__schema__?.kind;

      console.log(`Checking ${uid} => kind: ${kind}`);

      if (kind === "singleType") {
        try {
          const entry = await strapi.entityService.findMany(uid); // Use findMany for safety
          singles.push({
            uid,
            displayName: ct.info.displayName || uid,
            data: entry || {},
          });
        } catch (err) {
          console.error(`Error loading single: ${uid}`, err);
        }
      }
    }

    ctx.send(singles);
  },
};
