'use strict';

/**
 * dhanuvachapuram router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::dhanuvachapuram.dhanuvachapuram');
