'use strict';

/**
 * dhanuvachapuram controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::dhanuvachapuram.dhanuvachapuram');
