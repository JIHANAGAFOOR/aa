'use strict';

/**
 * attingal service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::attingal.attingal');
