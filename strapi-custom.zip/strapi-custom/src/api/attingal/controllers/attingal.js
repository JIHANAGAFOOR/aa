'use strict';

/**
 * attingal controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::attingal.attingal');
