'use strict';

/**
 * malayinkeezhu controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::malayinkeezhu.malayinkeezhu');
