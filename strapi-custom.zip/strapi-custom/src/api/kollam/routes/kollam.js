'use strict';

/**
 * kollam router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::kollam.kollam');
