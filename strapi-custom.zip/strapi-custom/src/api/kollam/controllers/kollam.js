'use strict';

/**
 * kollam controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::kollam.kollam');
