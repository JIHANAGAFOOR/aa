// const fs = require("fs");
// const path = require("path");

// function generateFromTemplate(templateName, newNames) {
//   const apiBase = path.join(__dirname, "../api");
//   const templatePath = path.join(apiBase, templateName);

//   newNames.forEach((name) => {
//     const newApiPath = path.join(apiBase, name);
//     if (fs.existsSync(newApiPath)) {
//       console.log(`⚠️  ${name} already exists. Skipping...`);
//       return;
//     }

//     fs.mkdirSync(newApiPath, { recursive: true });

//     ["controllers", "routes", "services"].forEach((folder) => {
//       const srcFolder = path.join(templatePath, folder);
//       const destFolder = path.join(newApiPath, folder);
//       fs.mkdirSync(destFolder, { recursive: true });

//       const srcFile = path.join(srcFolder, `${templateName}.js`);
//       const destFile = path.join(destFolder, `${name}.js`);

//       if (fs.existsSync(srcFile)) {
//         let fileContent = fs.readFileSync(srcFile, "utf8");
//         fileContent = fileContent.replaceAll("chackai", name);
//         fs.writeFileSync(destFile, fileContent, "utf8");
//       }
//     });

//     const contentTypeFolder = path.join(newApiPath, "content-types", name);
//     fs.mkdirSync(contentTypeFolder, { recursive: true });

//     const schemaTemplatePath = path.join(
//       templatePath,
//       "content-types",
//       templateName,
//       "schema.json"
//     );

//     if (!fs.existsSync(schemaTemplatePath)) {
//       console.error(`❌ Missing schema at ${schemaTemplatePath}`);
//       return;
//     }

//     const schema = JSON.parse(fs.readFileSync(schemaTemplatePath, "utf8"));

//     const pluralName = `${name}s`;
//     const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);

//     schema.collectionName = pluralName;
//     schema.info.singularName = name;
//     schema.info.pluralName = pluralName;
//     schema.info.displayName = capitalizedName;

//     const newSchemaPath = path.join(contentTypeFolder, "schema.json");
//     fs.writeFileSync(newSchemaPath, JSON.stringify(schema, null, 2), "utf8");

//     const mmPath = path.join(
//       templatePath,
//       "content-types",
//       templateName,
//       "mm.js"
//     );
//     if (fs.existsSync(mmPath)) {
//       fs.copyFileSync(mmPath, path.join(contentTypeFolder, "mm.js"));
//     }

//     console.log(`✅ Created API for: ${name}`);
//   });
// }

// function deleteAPI(name) {
//   const apiBase = path.join(__dirname, "../api");
//   const apiPath = path.join(apiBase, name);

//   if (!fs.existsSync(apiPath)) {
//     console.log(`⚠️ ${name} does not exist.`);
//     return false;
//   }

//   // Recursively delete folder and contents
//   fs.rmSync(apiPath, { recursive: true, force: true });
//   console.log(`🗑️ Deleted API for: ${name}`);
//   return true;
// }
// // module.exports = generateFromTemplate;
// module.exports = {
//  generateFromTemplate,
//   deleteAPI,
// };

// const fs = require("fs");
// const path = require("path");
// const strapiFactory = require("@strapi/strapi");

// async function generateFromTemplate(templateName, newNames) {
//   const apiBase = path.join(__dirname, "../api");
//   const templatePath = path.join(apiBase, templateName);

//   for (const name of newNames) {
//     const newApiPath = path.join(apiBase, name);
//     if (fs.existsSync(newApiPath)) {
//       console.log(`⚠️  ${name} already exists. Skipping...`);
//       continue;
//     }

//     fs.mkdirSync(newApiPath, { recursive: true });

//     ["controllers", "routes", "services"].forEach((folder) => {
//       const srcFolder = path.join(templatePath, folder);
//       const destFolder = path.join(newApiPath, folder);
//       fs.mkdirSync(destFolder, { recursive: true });

//       const srcFile = path.join(srcFolder, `${templateName}.js`);
//       const destFile = path.join(destFolder, `${name}.js`);

//       if (fs.existsSync(srcFile)) {
//         let fileContent = fs.readFileSync(srcFile, "utf8");
//         fileContent = fileContent.replaceAll("chackai", name);
//         fs.writeFileSync(destFile, fileContent, "utf8");
//       }
//     });

//     const contentTypeFolder = path.join(newApiPath, "content-types", name);
//     fs.mkdirSync(contentTypeFolder, { recursive: true });

//     const schemaTemplatePath = path.join(
//       templatePath,
//       "content-types",
//       templateName,
//       "schema.json"
//     );

//     if (!fs.existsSync(schemaTemplatePath)) {
//       console.error(`❌ Missing schema at ${schemaTemplatePath}`);
//       continue;
//     }

//     const schema = JSON.parse(fs.readFileSync(schemaTemplatePath, "utf8"));

//     const pluralName = `${name}s`;
//     const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);

//     schema.collectionName = pluralName;
//     schema.info.singularName = name;
//     schema.info.pluralName = pluralName;
//     schema.info.displayName = capitalizedName;

//     const newSchemaPath = path.join(contentTypeFolder, "schema.json");
//     fs.writeFileSync(newSchemaPath, JSON.stringify(schema, null, 2), "utf8");

//     const mmPath = path.join(
//       templatePath,
//       "content-types",
//       templateName,
//       "mm.js"
//     );
//     if (fs.existsSync(mmPath)) {
//       fs.copyFileSync(mmPath, path.join(contentTypeFolder, "mm.js"));
//     }

//     console.log(`✅ Created API for: ${name}`);

//     // Inject initial data
//     await createInitialData(name);
//   }
// }

// async function createInitialData(name) {
//   const strapi = await strapiFactory().load();

//   const uid = `api::${name}.${name}`;
//   try {
//     const existing = await strapi.entityService.findMany(uid);
//     if (existing && existing.length > 0) {
//       console.log(`ℹ️ ${name} entry already exists, skipping init data.`);
//       await strapi.destroy();
//       return;
//     }

//     const result = await strapi.entityService.create(uid, {
//       data: {
//         iti_name: name,
//       },
//     });

//     console.log(`✅ Set iti_name for ${name}:`, result?.iti_name || result);
//   } catch (err) {
//     console.error(`❌ Failed to insert initial data for ${name}:`, err.message);
//   }

//   await strapi.destroy();
// }

// function deleteAPI(name) {
//   const apiBase = path.join(__dirname, "../api");
//   const apiPath = path.join(apiBase, name);

//   if (!fs.existsSync(apiPath)) {
//     console.log(`⚠️ ${name} does not exist.`);
//     return false;
//   }

//   fs.rmSync(apiPath, { recursive: true, force: true });
//   console.log(`🗑️ Deleted API for: ${name}`);
//   return true;
// }

// module.exports = {
//   generateFromTemplate,
//   deleteAPI,
// };

const fs = require("fs");
const path = require("path");
const strapi = require("@strapi/strapi");


async function generateFromTemplate(templateName, newNames) {
  const apiBase = path.join(__dirname, "../api");
  const disabledBase = path.join(__dirname, "../disabled");
  const templatePath = path.join(apiBase, templateName);

  for (const name of newNames) {
    const newApiPath = path.join(apiBase, name);
    const disabledPath = path.join(disabledBase, name);

    // ✅ If the API exists in 'api', skip
    if (fs.existsSync(newApiPath)) {
      console.log(`⚠️ ${name} already exists in 'api'. Skipping...`);
      continue;
    }

    // ✅ If exists in 'disabled', move it back to 'api'
    if (fs.existsSync(disabledPath)) {
      fs.renameSync(disabledPath, newApiPath);
      console.log(`🔄 Moved "${name}" from 'disabled' back to 'api'.`);
      continue;
    }

    // ✅ If not in 'api' or 'disabled', create new from template
    fs.mkdirSync(newApiPath, { recursive: true });

    ["controllers", "routes", "services"].forEach((folder) => {
      const srcFolder = path.join(templatePath, folder);
      const destFolder = path.join(newApiPath, folder);
      fs.mkdirSync(destFolder, { recursive: true });

      const srcFile = path.join(srcFolder, `${templateName}.js`);
      const destFile = path.join(destFolder, `${name}.js`);

      if (fs.existsSync(srcFile)) {
        let fileContent = fs.readFileSync(srcFile, "utf8");
        fileContent = fileContent.replaceAll("chackai", name);
        fs.writeFileSync(destFile, fileContent, "utf8");
      }
    });

    const contentTypeFolder = path.join(newApiPath, "content-types", name);
    fs.mkdirSync(contentTypeFolder, { recursive: true });

    const schemaTemplatePath = path.join(
      templatePath,
      "content-types",
      templateName,
      "schema.json"
    );

    if (!fs.existsSync(schemaTemplatePath)) {
      console.error(`❌ Missing schema at ${schemaTemplatePath}`);
      continue;
    }

    const schema = JSON.parse(fs.readFileSync(schemaTemplatePath, "utf8"));

    const pluralName = `${name}s`;
    const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);

    schema.collectionName = pluralName;
    schema.info.singularName = name;
    schema.info.pluralName = pluralName;
    schema.info.displayName = capitalizedName;

    const newSchemaPath = path.join(contentTypeFolder, "schema.json");
    fs.writeFileSync(newSchemaPath, JSON.stringify(schema, null, 2), "utf8");

    const mmPath = path.join(
      templatePath,
      "content-types",
      templateName,
      "mm.js"
    );
    if (fs.existsSync(mmPath)) {
      fs.copyFileSync(mmPath, path.join(contentTypeFolder, "mm.js"));
    }

    console.log(`✅ Created API for: ${name}`);

    // Inject initial data
    await createInitialData(name);
  }
}
async function createInitialData(name) {
  let strapiInstance = null;

  try {
    // Use the imported strapi directly
    strapiInstance = await strapi().load();

    const uid = `api::${name}.${name}`;

    const existing = await strapiInstance.entityService.findMany(uid);
    if (existing && existing.length > 0) {
      console.log(`ℹ️ ${name} entry already exists, skipping init data.`);
      return;
    }

    const result = await strapiInstance.entityService.create(uid, {
      data: {
        iti_name: name,
      },
    });

    console.log(`✅ Set iti_name for ${name}:`, result?.iti_name || result);
  } catch (err) {
    console.error(`❌ Failed to insert initial data for ${name}:`, err.message);
  } finally {
    if (strapiInstance) {
      await strapiInstance.destroy();
    }
  }
}


function deleteAPI(name) {
  const apiBase = path.join(__dirname, "../api"); // current location of API
  const apiPath = path.join(apiBase, name); // specific API folder to move
  const disabledPath = path.join(__dirname, "../disabled", name); // target path

  if (!fs.existsSync(apiPath)) {
    console.log(`⚠️ API "${name}" does not exist in 'api'.`);
    return false;
  }

  if (fs.existsSync(disabledPath)) {
    console.log(`⚠️ "${name}" already exists in 'disabled'.`);
    return false;
  }

  fs.renameSync(apiPath, disabledPath); // move folder
  console.log(`📦 Moved API "${name}" to disabled folder.`);
  return true;
}
module.exports = {
  generateFromTemplate,
  deleteAPI,
};