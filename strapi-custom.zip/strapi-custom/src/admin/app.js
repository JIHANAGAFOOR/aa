
import favicon from "./extensions/favicon.png";
export default {
  config: {
    head: {
      title: "ITI Admin Panel", // Changed to ITI
      favicon: favicon, // Optional: if you also changed the favicon
    },
    translations: {
      en: {
        "app.components.Leftmenu.navbranc.title": "ITI",
        "Auth.form.welcome.subtitle": "Log in to your ITI account", // Changed Strapi to ITI
        "app.components.LeftMenu.navbrand.title": "Dashboard",
        "Auth.form.welcome.title": "Welcome to ITI", // Fixed typo (ITIs → ITI)
        "app.components.GuidedTour.title": "Welcome to ITI", // Fixed typo (ITIS → ITI)
      },
    },
    tutorials: false,
    locales: [],
  },
  bootstrap() {
    // Set default title
    document.title = "ITI Admin";

    // Create a title observer that changes "Strapi" to "ITI" in all page titles
    const titleObserver = new MutationObserver(() => {
      if (document.title.includes("Strapi")) {
        document.title = document.title.replace("Strapi", "ITI");
      }
    });

    // Start observing title changes
    titleObserver.observe(document.querySelector("head > title"), {
      subtree: true,
      characterData: true,
      childList: true,
    });
  },
  register(app) {
    const indexRoute = app.router.routes.find(({ index }) => index);
    if (!indexRoute) throw new Error("unable to find index page");
    indexRoute.lazy = async () => {
      const { HomePage } = await import("./HomePage");
      return { Component: HomePage };
    };
  },
};
