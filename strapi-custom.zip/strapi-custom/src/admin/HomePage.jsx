import { TextInput, Button, Box, Typography } from "@strapi/design-system";
import { useEffect, useState, useMemo } from "react";
import { useFetchClient } from "@strapi/strapi/admin";
import ITI from "./ITIList.json";
import axios from "axios";
import React from "react";
import { styles } from "./style";

const HomePage = () => {
  const [input, setInput] = useState("");
  const [message, setMessage] = useState("");
  const [singles, setSingles] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [userRole, setUserRole] = useState("");
  const [currentUser, setCurrentUser] = useState(null);
  const [actionLoading, setActionLoading] = useState({});
  const [initialLoading, setInitialLoading] = useState(true);

  const { get } = useFetchClient();
  const itemsPerPage = 10;

  useEffect(() => {
    fetchSingles();
    fetchUserData();
  }, []);

  const fetchSingles = async () => {
    try {
      console.log("\n\njjj\n\n");

      setInitialLoading(true);
      const res = await axios.get("/api/list-singles");
      setSingles(res.data);
      // setMessage("✅ ITI loaded successfully");
    } catch (err) {

      setMessage("❌ Failed to fetch ITI", err);
    } finally {
      setInitialLoading(false);
    }
  };

  const handleDelete = async (name) => {
    if (!window.confirm(`Are you sure you want to delete "${name}"?`)) return;

    setActionLoading((prev) => ({ ...prev, [`delete_${name}`]: true }));

    try {
      const res = await axios.post("/api/delete", { name: name });
      setMessage(res.data.message);
      await fetchSingles(); // Refresh list after deletion
    } catch (err) {
      console.error(err);
      setMessage("❌ Failed to delete ITI");
    } finally {
      setActionLoading((prev) => ({ ...prev, [`delete_${name}`]: false }));
    }
  };

  const handleCreateITI = async (value) => {
    const names = value
      .split(",")
      .map((n) => n.trim())
      .filter(Boolean);
    if (!names.length) return;

    setActionLoading((prev) => ({ ...prev, [`create_${value}`]: true }));

    try {
      const res = await axios.post("/api/generate", { names });
      // setMessage(res.data.message);
      setMessage("Creating ITIs ......");
      await fetchSingles(); // refresh list after creation
      setInput(""); // Clear input after successful creation
    } catch (err) {
      console.error(err);
      setMessage("❌ Failed to generate ITIs");
    } finally {
      setActionLoading((prev) => ({ ...prev, [`create_${value}`]: false }));
    }
  };

  const fetchUserData = async () => {
    try {
      const response = await get("/admin/users/me");
      // console.log("User data from /admin/users/me:", response.data);
      if (response.data) {
        console.log("fff" + JSON.stringify(response.data.data.roles[0]));
        setCurrentUser(response.data);

        // Extract role information
        if (response.data.data.roles && response.data.data.roles.length > 0) {
          const roleCode = response.data.data.roles[0].code;
          console.log("User role code:", roleCode);
          setUserRole(roleCode);
        }
      }
      setLoading(false);
    } catch (error) {
      console.error("Failed to fetch user with fetch client:", error);
    }
  };

  // Spinner component for consistent styling
  const LoadingSpinner = ({ size = 16, color = "#ffffff" }) => (
    <div
      style={{
        width: `${size}px`,
        height: `${size}px`,
        border: `2px solid transparent`,
        borderTop: `2px solid ${color}`,
        borderRadius: "50%",
        animation: "spin 1s linear infinite",
        display: "inline-block",
        marginRight: size === 16 ? "8px" : "0",
      }}
    />
  );

  // Enhanced styles object with spinner animation
  const enhancedStyles = {
    ...styles,
    buttonWithSpinner: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      minWidth: "100px",
      position: "relative",
    },
    spinnerKeyframes: `
      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    `,
    actionButton: {
      ...styles.actionButton,
      minWidth: "90px",
      height: "32px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "6px",
      transition: "all 0.2s ease",
    },
    disabledButton: {
      opacity: 0.6,
      cursor: "not-allowed",
      pointerEvents: "none",
    },
    cardActionButton: {
      minWidth: "100px",
      height: "36px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "8px",
      borderRadius: "6px",
      border: "1px solid",
      fontSize: "14px",
      fontWeight: "500",
      cursor: "pointer",
      transition: "all 0.2s ease",
      textDecoration: "none",
    },
    activateButton: {
      backgroundColor: "#10b981",
      borderColor: "#10b981",
      color: "white",
    },
    activateButtonHover: {
      backgroundColor: "#059669",
      borderColor: "#059669",
    },
    disableButton: {
      backgroundColor: "#ef4444",
      borderColor: "#ef4444",
      color: "white",
    },
    disableButtonHover: {
      backgroundColor: "#dc2626",
      borderColor: "#dc2626",
    },
    activatedButton: {
      backgroundColor: "#f3f4f6",
      borderColor: "#d1d5db",
      color: "#6b7280",
      cursor: "not-allowed",
    },
  };

  // Check if user role matches single type name (case insensitive)
  const isRoleMatchingSingleType = (singleTypeName) => {
    if (!userRole || !singleTypeName) return false;
    return (
      userRole.toLowerCase().includes(singleTypeName.toLowerCase()) ||
      singleTypeName.toLowerCase().includes(userRole.toLowerCase())
    );
  };

  // Merge and filter data based on search term and user role

  const mergedList = useMemo(() => {
    const merged = [
      // All existing singles, marked as created
      ...singles.map((single) => ({
        label: single.displayName,
        value: single.displayName,
        uid: single.uid,
        description: single.description || "",
        created: true,
        created_date: single.data.createdAt,
        last_updated_date: single.data.updatedAt,
      })),

      // Add only ITIs not in singles, setting label properly
      ...ITI.filter(
        (iti) =>
          !singles.some(
            (single) =>
              single.displayName.toLowerCase() === iti.value.toLowerCase()
          )
      ).map((iti) => ({
        label: iti.name || iti.value,
        value: iti.value,
        description: iti.description || "",
        uid: "Not Created",
        created: false,
        created_date: iti.createdAt,
        last_updated_date: iti.updatedAt,
      })),
    ];

    // Filter based on user role
    let roleFilteredList = merged;
    if (userRole !== "strapi-super-admin") {
      roleFilteredList = merged.filter(
        (item) =>
          isRoleMatchingSingleType(item.value) ||
          isRoleMatchingSingleType(item.label)
      );
    }

    // Filter based on search term
    if (searchTerm.trim()) {
      return roleFilteredList.filter(
        (item) =>
          item.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.value.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return roleFilteredList;
  }, [singles, searchTerm, userRole]);

  // Pagination logic
  const totalPages = Math.ceil(mergedList.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedList = mergedList.slice(startIndex, startIndex + itemsPerPage);
  console.log("" + JSON.stringify(mergedList));

  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const clearMessage = () => {
    setTimeout(() => setMessage(""), 5000);
  };

  useEffect(() => {
    if (message) {
      clearMessage();
    }
  }, [message]);

  // Add CSS animation for spinner
  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = enhancedStyles.spinnerKeyframes;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  if (initialLoading) {
    return (
      <div style={styles.pageContainer}>
        <div style={styles.loadingContainer}>
          <LoadingSpinner size={32} color="#4945ff" />
          <p style={styles.loadingText}>Loading dashboard...</p>
        </div>
      </div>
    );
  }

  // Show access denied message for non-super-admin users with no matching single types
  if (
    userRole !== "strapi-super-admin" &&
    mergedList.length === 0 &&
    !searchTerm
  ) {
    return (
      <div style={styles.pageContainer}>
        <div style={{ marginBottom: "4px" }}>
          <h1 style={styles.headerTitle}>My Content Overview</h1>
          <p style={styles.subTitle}>View your accessible content models</p>
        </div>

        <div style={styles.tableContainer}>
          <div
            style={{
              padding: "60px 40px",
              textAlign: "center",
              backgroundColor: "#f6f7f9",
              borderRadius: "12px",
              border: "1px solid #ddd4f0",
            }}
          >
            <div
              style={{
                width: "64px",
                height: "64px",
                backgroundColor: "#e1e5e9",
                borderRadius: "50%",
                margin: "0 auto 24px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "24px",
              }}
            >
              📋
            </div>
            <h3
              style={{
                color: "#32324d",
                marginBottom: "16px",
                fontSize: "20px",
                fontWeight: "600",
              }}
            >
              No Content Available
            </h3>
            <p
              style={{
                color: "#666687",
                marginBottom: "8px",
                fontSize: "16px",
              }}
            >
              Role: <strong style={{ color: "#4945ff" }}>{userRole}</strong>
            </p>
            <p
              style={{
                color: "#666687",
                lineHeight: "1.5",
                maxWidth: "400px",
                margin: "0 auto",
              }}
            >
              You currently don't have access to any content models that match
              your role permissions.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.pageContainer}>
      {/* Header Section */}
      <div style={{ marginBottom: "0px" }}>
        <h1 style={styles.headerTitle}>
          {userRole === "strapi-super-admin"
            ? "ITI Master Dashboard"
            : "My ITI Content Overview"}
        </h1>
        <p style={styles.subTitle}>
          {userRole === "strapi-super-admin"
            ? "Manage your ITI content models"
            : `View your accessible content models `}
        </p>

        {/* Message Display */}
        {message && (
          <div
            style={
              message.includes("❌")
                ? styles.messageError
                : styles.messageSuccess
            }
          >
            {message}
          </div>
        )}
      </div>

      {/* Search and Controls Section */}
      {userRole === "strapi-super-admin" && (
        <div style={styles.controlsContainer}>
          <div style={styles.searchContainer}>
            <TextInput
              placeholder="Search by name..."
              value={searchTerm}
              onChange={handleSearchChange}
              style={styles.searchInput}
            />
          </div>
          <div style={styles.statsContainer}>
            <span style={styles.statsText}>
              Showing {paginatedList.length} of {mergedList.length} items
              {userRole !== "strapi-super-admin" && (
                <span style={{ color: "#666687", fontSize: "12px" }}>
                  {" "}
                  (filtered by role)
                </span>
              )}
            </span>
          </div>
        </div>
      )}

      {/* Table Section */}
      <div style={styles.tableContainer}>
        {mergedList.length === 0 ? (
          <p style={styles.emptyState}>
            {searchTerm
              ? `No results found for "${searchTerm}"`
              : userRole === "strapi-super-admin"
                ? "No ITI's found. Create some using the form above."
                : "No content models found that match your role."}
          </p>
        ) : userRole !== "strapi-super-admin" ? (
          // Card layout for non-super-admin users
          <div>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
                gap: "20px",
                // marginTop: "20px",
              }}
            >
              {paginatedList.map((s, i) => (
                <div
                  key={`${s.value}_${i}`}
                  style={{
                    backgroundColor: "#ffffff",
                    border: "1px solid #eaecf0",
                    borderRadius: "12px",
                    padding: "24px",
                    boxShadow: "0 1px 3px rgba(16, 24, 40, 0.1)",
                    transition: "all 0.2s ease",
                    cursor: "default",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginBottom: "16px",
                    }}
                  >
                    <div
                      style={{
                        width: "40px",
                        height: "40px",
                        backgroundColor: s.created ? "#d1fae5" : "#fef3c7",
                        borderRadius: "8px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: "12px",
                        fontSize: "18px",
                      }}
                    >
                      {s.created ? "📄" : "📝"}
                    </div>
                    <div style={{ flex: 1 }}>
                      <h3
                        style={{
                          color: "#101828",
                          fontSize: "18px",
                          fontWeight: "600",
                          margin: "0 0 4px 0",
                          lineHeight: "1.2",
                        }}
                      >
                        {s.label}
                      </h3>
                      <span
                        style={{
                          display: "inline-block",
                          padding: "4px 8px",
                          backgroundColor: s.created ? "#d1fae5" : "#fef3c7",
                          color: s.created ? "#059669" : "#d97706",
                          fontSize: "12px",
                          fontWeight: "500",
                          borderRadius: "6px",
                          textTransform: "uppercase",
                          letterSpacing: "0.5px",
                        }}
                      >
                        {s.created ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </div>

                 

                  <div
                    style={{
                      borderTop: "1px solid #eaecf0",
                      paddingTop: "16px",
                      // marginBottom: "16px",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        fontSize: "13px",
                        color: "#667085",
                      }}
                    >
                      <span>
                        <strong>Last Updated Date</strong>
                      </span>
                      <span
                        style={{
                          // padding: "2px 6px",
                          backgroundColor: "#f9fafb",
                          borderRadius: "4px",
                          fontSize: "11px",
                          fontFamily: "monospace",
                        }}
                      >
                        {s.created
                          ? s?.last_updated_date
                            ? new Date(s.last_updated_date)
                                .toLocaleDateString("en-GB")
                                .replace(/\//g, "-") // "12-06-2025"
                            : "Not Updated yet"
                          : "Not Created yet"}
                      </span>
                    </div>
                  </div>

                  {/* Card Action Buttons */}
                  <div
                    style={{
                      display: "flex",
                      gap: "8px",
                      justifyContent: "flex-end",
                    }}
                  ></div>
                </div>
              ))}
            </div>
            <div
              style={{
                backgroundColor: "#f6f6f9",
                border: "1px solid #e3e3e7",
                borderRadius: "12px",
                padding: "24px",
                fontFamily: `'Inter', sans-serif`,
                fontSize: "14px",
                color: "#4a4a6a",
                lineHeight: "1.7",
                boxShadow: "0 1px 3px rgba(0, 0, 0, 0.04)",
                marginTop: "20px",
              }}
            >
              <h4
                style={{
                  color: "#32324d",
                  fontSize: "16px",
                  fontWeight: "600",
                  marginBottom: "16px",
                }}
              >
                Content Management Guidelines
              </h4>

              <p>
                The ITI dashboard is connected to <strong>Strapi CMS</strong>, a
                flexible and user-friendly content management system designed to
                simplify your content editing experience.
              </p>

              <p style={{ marginTop: "10px" }}>
                Each ITI has its own entry as a <strong>Single Type</strong>{" "}
                model under the <strong>Content Manager</strong> tab in the
                sidebar. You can use this section to manage:
              </p>

              <ul
                style={{
                  margin: "12px 0 12px 20px",
                  paddingLeft: "0",
                  listStyleType: "disc",
                }}
              >
                <li>
                  Edit institute profile details like name, code, and contact
                  info
                </li>
                <li>
                  Upload or replace images such as building photos, lab images,
                  and event galleries
                </li>
                <li>
                  Update infrastructure and facilities details (e.g., workshops,
                  classrooms, labs)
                </li>
                <li>
                  Maintain records of staff members, departments, and training
                  programs
                </li>
                <li>
                  Add or modify recent activities, achievements, and
                  announcements
                </li>
              </ul>

              <p>
                Strapi provides an intuitive editor with fields for text,
                images, numbers, dates, and relational data. You can easily:
              </p>

              <ul style={{ margin: "12px 0 12px 20px", listStyleType: "disc" }}>
                <li>Click on any field to edit its content</li>
                <li>Use toggles for enabling/disabling sections</li>
                <li>Use the media library to manage images efficiently</li>
                <li>
                  Click "Save" to store changes 
                </li>
              </ul>

              <p>
                All updates made here will be reflected instantly on your public
                ITI website. Please ensure data accuracy before publishing.
              </p>

              <p style={{ marginTop: "10px" }}>
                For any doubts, data issues, or technical support, please reach
                out to the central admin team.
              </p>
            </div>
          </div>
        ) : (
          // Table layout for super-admin users
          <>
            <div style={styles.tableWrapper}>
              <table style={styles.table}>
                <thead style={styles.tableHeader}>
                  <tr>
                    <th style={styles.tableHeaderCell}>Name</th>

                    <th style={styles.tableHeaderCell}>Last Published Date</th>
                    <th style={styles.tableHeaderCell}>Status</th>
                    <th style={styles.tableHeaderCell}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paginatedList.map((s, i) => (
                    <tr key={`${s.value}_${i}`} style={styles.tableRow}>
                      <td style={styles.tableCell}>
                        <div style={styles.nameCell}>
                          <span style={styles.nameText}>{s.label}</span>
                          {s.description && (
                            <span style={styles.descriptionText}>
                              {s.description}
                            </span>
                          )}
                        </div>
                      </td>

                      <td style={styles.tableCell}>
                        {s.created
                          ? s?.last_updated_date
                            ? new Date(s.last_updated_date)
                                .toLocaleDateString("en-GB")
                                .replace(/\//g, "-") // "12-06-2025"
                            : "Not Updated yet"
                          : "Not Created yet"}

                        {/* {s?.last_updated_date ?? "Not Updated yet"} */}
                      </td>
                      <td style={styles.tableCell}>
                        <span
                          style={
                            s.created
                              ? styles.statusActive
                              : styles.statusInactive
                          }
                        >
                          {s.created ? "Active" : "Inactive"}
                        </span>
                      </td>
                      <td style={styles.tableCell}>
                        <div style={styles.actionButtons}>
                          {!s.created ? (
                            <Button
                              variant="success"
                              size="S"
                              onClick={() => handleCreateITI(s.value)}
                              disabled={actionLoading[`create_${s.value}`]}
                              style={{
                                ...enhancedStyles.actionButton,
                                ...(actionLoading[`create_${s.value}`]
                                  ? enhancedStyles.disabledButton
                                  : {}),
                              }}
                            >
                              <div style={enhancedStyles.buttonWithSpinner}>
                                {actionLoading[`create_${s.value}`] && (
                                  <LoadingSpinner size={16} color="#ffffff" />
                                )}
                                {actionLoading[`create_${s.value}`]
                                  ? "Activating..."
                                  : "Activate"}
                              </div>
                            </Button>
                          ) : (
                            <Button
                              variant="secondary"
                              size="S"
                              disabled
                              style={enhancedStyles.actionButton}
                            >
                              Activated
                            </Button>
                          )}
                          <Button
                            variant="danger"
                            size="S"
                            onClick={() => handleDelete(s.value)}
                            disabled={actionLoading[`delete_${s.value}`]}
                            style={{
                              ...enhancedStyles.actionButton,
                              ...(actionLoading[`delete_${s.value}`]
                                ? enhancedStyles.disabledButton
                                : {}),
                            }}
                          >
                            <div style={enhancedStyles.buttonWithSpinner}>
                              {actionLoading[`delete_${s.value}`] && (
                                <LoadingSpinner size={16} color="#ffffff" />
                              )}
                              {actionLoading[`delete_${s.value}`]
                                ? "Disabling..."
                                : "Disable"}
                            </div>
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {/* Pagination - shown for both layouts */}
        {totalPages > 1 && (
          <div style={styles.paginationContainer}>
            <Button
              variant="tertiary"
              size="S"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              style={styles.paginationButton}
            >
              Previous
            </Button>

            <div style={styles.pageNumbers}>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                (page) => {
                  // Show first page, last page, current page, and pages around current
                  const showPage =
                    page === 1 ||
                    page === totalPages ||
                    Math.abs(page - currentPage) <= 1;

                  if (!showPage && page === 2 && currentPage > 4) {
                    return (
                      <span key={page} style={styles.ellipsis}>
                        ...
                      </span>
                    );
                  }
                  if (
                    !showPage &&
                    page === totalPages - 1 &&
                    currentPage < totalPages - 3
                  ) {
                    return (
                      <span key={page} style={styles.ellipsis}>
                        ...
                      </span>
                    );
                  }
                  if (!showPage) return null;

                  return (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "tertiary"}
                      size="S"
                      onClick={() => handlePageChange(page)}
                      style={styles.pageButton}
                    >
                      {page}
                    </Button>
                  );
                }
              )}
            </div>

            <Button
              variant="tertiary"
              size="S"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              style={styles.paginationButton}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export { HomePage };
