'use strict';

/**
 * w-kazhakkuttom router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::w-kazhakkuttom.w-kazhakkuttom');
