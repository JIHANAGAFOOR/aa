'use strict';

/**
 * w-kazhakkuttom controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::w-kazhakkuttom.w-kazhakkuttom');
