const { ApplicationError } = require("@strapi/utils").errors;

module.exports = {
  async beforeCreate(event) {
    validateNoDuplicateComponents(event.params.data);
  },

  async beforeUpdate(event) {
    validateNoDuplicateComponents(event.params.data);
  },
};

function validateNoDuplicateComponents(data) {
  const dynamicZoneFields = [
    "Institute",
    "Admission",
    "Academics",
    "Trainees",
    "Facilities",
    "Placement",
    "Notification",
    "Download",
  ];

  const errorMessages = [];

  for (const field of dynamicZoneFields) {
    const zoneData = data[field];
    if (!Array.isArray(zoneData)) continue;

    const seen = new Set();

    for (const component of zoneData) {
      const compUID = component.__component;
      if (seen.has(compUID)) {
        errorMessages.push(
          `Component "${compUID}" is already added in "${field}". Only one instance is allowed.`
        );
      }
        seen.add(compUID);
        return true
    }
  }

  if (errorMessages.length > 0) {
    throw new ApplicationError(errorMessages.join("\n"));
  }
}
