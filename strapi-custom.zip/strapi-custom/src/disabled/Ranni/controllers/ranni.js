'use strict';

/**
 * ranni controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::ranni.ranni');
