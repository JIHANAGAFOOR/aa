'use strict';

/**
 * ranni service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::ranni.ranni');
